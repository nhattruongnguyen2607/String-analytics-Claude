// ============================================================
// SOLAR PLANT PERFORMANCE DATA (pre-processed from export)
// Source: datahub_export_plant_daily_20260316_091153.xlsx
// ============================================================

const PLANT_DATA = {
  meta: {
    plant: "CMES Solar Plant",
    totalPanels: 3214,
    totalInverters: 34,
    dataRange: { start: "2026-03-09", end: "2026-03-15" },
    capacity: 15.66,  // kWp (primary)
    lastUpdated: "2026-03-15"
  },

  daily: [
    {"date":"2026-03-09","avg":0.8572,"min":0.09,"max":1.0,"count":3214,"std":0.1128},
    {"date":"2026-03-10","avg":0.8525,"min":0.0,"max":1.0,"count":3214,"std":0.1247},
    {"date":"2026-03-11","avg":0.8512,"min":0.0,"max":1.0,"count":3214,"std":0.1357},
    {"date":"2026-03-12","avg":0.8570,"min":-0.01,"max":1.0,"count":3214,"std":0.1270},
    {"date":"2026-03-13","avg":0.8272,"min":-0.01,"max":1.0,"count":3214,"std":0.1408},
    {"date":"2026-03-14","avg":0.8144,"min":-0.01,"max":1.0,"count":3214,"std":0.1808},
    {"date":"2026-03-15","avg":0.6018,"min":-0.03,"max":1.0,"count":3214,"std":0.3335}
  ],

  inverters: [
    {"inverter":"I01","avg":0.8346,"count":2646},
    {"inverter":"I02","avg":0.7978,"count":2597},
    {"inverter":"I03","avg":0.7935,"count":2527},
    {"inverter":"I04","avg":0.7886,"count":2422},
    {"inverter":"I05","avg":0.7978,"count":1729},
    {"inverter":"I06","avg":0.8166,"count":1603},
    {"inverter":"I07","avg":0.7932,"count":1260},
    {"inverter":"I08","avg":0.7584,"count":980},
    {"inverter":"I09","avg":0.8415,"count":917},
    {"inverter":"I10","avg":0.8370,"count":700},
    {"inverter":"I11","avg":0.8291,"count":602},
    {"inverter":"I12","avg":0.7977,"count":483},
    {"inverter":"I13","avg":0.8071,"count":490},
    {"inverter":"I14","avg":0.8062,"count":476},
    {"inverter":"I15","avg":0.8198,"count":343},
    {"inverter":"I16","avg":0.8025,"count":350},
    {"inverter":"I17","avg":0.8040,"count":322},
    {"inverter":"I18","avg":0.7638,"count":245},
    {"inverter":"I19","avg":0.7529,"count":245},
    {"inverter":"I20","avg":0.9129,"count":35},
    {"inverter":"I21","avg":0.8716,"count":105},
    {"inverter":"I22","avg":0.8670,"count":105},
    {"inverter":"I23","avg":0.8706,"count":105},
    {"inverter":"I24","avg":0.8688,"count":105},
    {"inverter":"I25","avg":0.8626,"count":112},
    {"inverter":"I26","avg":0.8619,"count":112},
    {"inverter":"I27","avg":0.8688,"count":112},
    {"inverter":"I28","avg":0.8612,"count":105},
    {"inverter":"I29","avg":0.8595,"count":112},
    {"inverter":"I30","avg":0.8647,"count":112},
    {"inverter":"I31","avg":0.8841,"count":105},
    {"inverter":"I32","avg":0.8792,"count":112},
    {"inverter":"I33","avg":0.8591,"count":112},
    {"inverter":"I34","avg":0.8638,"count":112}
  ],

  lowPerformance: [
    {"date":"2026-03-09","low_count":496},
    {"date":"2026-03-10","low_count":673},
    {"date":"2026-03-11","low_count":615},
    {"date":"2026-03-12","low_count":506},
    {"date":"2026-03-13","low_count":844},
    {"date":"2026-03-14","low_count":775},
    {"date":"2026-03-15","low_count":1753}
  ],

  distribution: [
    {"bucket":"< 0%","count":74,"color":"#ef4444"},
    {"bucket":"0–50%","count":1841,"color":"#f97316"},
    {"bucket":"50–70%","count":1466,"color":"#eab308"},
    {"bucket":"70–80%","count":2762,"color":"#84cc16"},
    {"bucket":"80–90%","count":8931,"color":"#22c55e"},
    {"bucket":"90–95%","count":4919,"color":"#10b981"},
    {"bucket":"95–100%","count":2505,"color":"#06b6d4"}
  ],

  worstPanels: [
    {"panel":"CMES-PR045-I08-M02-PV04","avg_perf":0.0157},
    {"panel":"CMES-PR045-I08-M01-PV02","avg_perf":0.0186},
    {"panel":"CMES-PR045-I08-M03-PV06","avg_perf":0.0229},
    {"panel":"CMES-PR023-I02-M05-PV09","avg_perf":0.0314},
    {"panel":"CMES-PR045-I07-M10-PV19","avg_perf":0.0543},
    {"panel":"CMES-PR045-I08-M03-PV05","avg_perf":0.0686},
    {"panel":"CMES-PR045-I08-M02-PV03","avg_perf":0.0743},
    {"panel":"CMES-PR045-I07-M07-PV13","avg_perf":0.0771},
    {"panel":"CMES-PR045-I08-M04-PV07","avg_perf":0.0814},
    {"panel":"CMES-PR045-I07-M05-PV09","avg_perf":0.0900},
    {"panel":"CMES-PR045-I08-M01-PV01","avg_perf":0.0929},
    {"panel":"CMES-PR045-I08-M06-PV11","avg_perf":0.1186},
    {"panel":"CMES-PR045-I07-M03-PV06","avg_perf":0.1371},
    {"panel":"CMES-PR045-I08-M05-PV09","avg_perf":0.1429},
    {"panel":"CMES-PR025-I02-M10-PV20","avg_perf":0.1471},
    {"panel":"CMES-PR025-I02-M05-PV09","avg_perf":0.1500},
    {"panel":"CMES-PR045-I07-M09-PV17","avg_perf":0.1571},
    {"panel":"CMES-PR026-I03-M06-PV12","avg_perf":0.1629},
    {"panel":"CMES-PR025-I02-M10-PV19","avg_perf":0.1829},
    {"panel":"CMES-PR045-I07-M08-PV15","avg_perf":0.1843}
  ],

  heatmap: [
    {"date":"2026-03-09","inverter":"I01","avg":0.8802},{"date":"2026-03-09","inverter":"I02","avg":0.8487},{"date":"2026-03-09","inverter":"I03","avg":0.8491},{"date":"2026-03-09","inverter":"I04","avg":0.8345},{"date":"2026-03-09","inverter":"I05","avg":0.8521},{"date":"2026-03-09","inverter":"I06","avg":0.8773},{"date":"2026-03-09","inverter":"I07","avg":0.8609},{"date":"2026-03-09","inverter":"I08","avg":0.8256},{"date":"2026-03-09","inverter":"I09","avg":0.8866},{"date":"2026-03-09","inverter":"I10","avg":0.8775},{"date":"2026-03-09","inverter":"I11","avg":0.8736},{"date":"2026-03-09","inverter":"I12","avg":0.8591},{"date":"2026-03-09","inverter":"I13","avg":0.8543},{"date":"2026-03-09","inverter":"I14","avg":0.8618},{"date":"2026-03-09","inverter":"I15","avg":0.8812},{"date":"2026-03-09","inverter":"I16","avg":0.8668},{"date":"2026-03-09","inverter":"I17","avg":0.8663},{"date":"2026-03-09","inverter":"I18","avg":0.8340},{"date":"2026-03-09","inverter":"I19","avg":0.8126},{"date":"2026-03-09","inverter":"I20","avg":0.9360},{"date":"2026-03-09","inverter":"I21","avg":0.8527},{"date":"2026-03-09","inverter":"I22","avg":0.8540},{"date":"2026-03-09","inverter":"I23","avg":0.8440},{"date":"2026-03-09","inverter":"I24","avg":0.8500},{"date":"2026-03-09","inverter":"I25","avg":0.8606},{"date":"2026-03-09","inverter":"I26","avg":0.8488},{"date":"2026-03-09","inverter":"I27","avg":0.8550},{"date":"2026-03-09","inverter":"I28","avg":0.8640},{"date":"2026-03-09","inverter":"I29","avg":0.8412},{"date":"2026-03-09","inverter":"I30","avg":0.8388},{"date":"2026-03-09","inverter":"I31","avg":0.8660},{"date":"2026-03-09","inverter":"I32","avg":0.8444},{"date":"2026-03-09","inverter":"I33","avg":0.8262},{"date":"2026-03-09","inverter":"I34","avg":0.8350},
    {"date":"2026-03-10","inverter":"I01","avg":0.8804},{"date":"2026-03-10","inverter":"I02","avg":0.8447},{"date":"2026-03-10","inverter":"I03","avg":0.8304},{"date":"2026-03-10","inverter":"I04","avg":0.8292},{"date":"2026-03-10","inverter":"I05","avg":0.8357},{"date":"2026-03-10","inverter":"I06","avg":0.8552},{"date":"2026-03-10","inverter":"I07","avg":0.8508},{"date":"2026-03-10","inverter":"I08","avg":0.8124},{"date":"2026-03-10","inverter":"I09","avg":0.8779},{"date":"2026-03-10","inverter":"I10","avg":0.8809},{"date":"2026-03-10","inverter":"I11","avg":0.8770},{"date":"2026-03-10","inverter":"I12","avg":0.8565},{"date":"2026-03-10","inverter":"I13","avg":0.8647},{"date":"2026-03-10","inverter":"I14","avg":0.8679},{"date":"2026-03-10","inverter":"I15","avg":0.8743},{"date":"2026-03-10","inverter":"I16","avg":0.8432},{"date":"2026-03-10","inverter":"I17","avg":0.8528},{"date":"2026-03-10","inverter":"I18","avg":0.8277},{"date":"2026-03-10","inverter":"I19","avg":0.8263},{"date":"2026-03-10","inverter":"I20","avg":0.9100},{"date":"2026-03-10","inverter":"I21","avg":0.8987},{"date":"2026-03-10","inverter":"I22","avg":0.8907},{"date":"2026-03-10","inverter":"I23","avg":0.8987},{"date":"2026-03-10","inverter":"I24","avg":0.8940},{"date":"2026-03-10","inverter":"I25","avg":0.8644},{"date":"2026-03-10","inverter":"I26","avg":0.8694},{"date":"2026-03-10","inverter":"I27","avg":0.8750},{"date":"2026-03-10","inverter":"I28","avg":0.8620},{"date":"2026-03-10","inverter":"I29","avg":0.8831},{"date":"2026-03-10","inverter":"I30","avg":0.8900},{"date":"2026-03-10","inverter":"I31","avg":0.9227},{"date":"2026-03-10","inverter":"I32","avg":0.9212},{"date":"2026-03-10","inverter":"I33","avg":0.9006},{"date":"2026-03-10","inverter":"I34","avg":0.9038},
    {"date":"2026-03-11","inverter":"I01","avg":0.8852},{"date":"2026-03-11","inverter":"I02","avg":0.8445},{"date":"2026-03-11","inverter":"I03","avg":0.8410},{"date":"2026-03-11","inverter":"I04","avg":0.8308},{"date":"2026-03-11","inverter":"I05","avg":0.8477},{"date":"2026-03-11","inverter":"I06","avg":0.8635},{"date":"2026-03-11","inverter":"I07","avg":0.8343},{"date":"2026-03-11","inverter":"I08","avg":0.8070},{"date":"2026-03-11","inverter":"I09","avg":0.8788},{"date":"2026-03-11","inverter":"I10","avg":0.8715},{"date":"2026-03-11","inverter":"I11","avg":0.8671},{"date":"2026-03-11","inverter":"I12","avg":0.8475},{"date":"2026-03-11","inverter":"I13","avg":0.8493},{"date":"2026-03-11","inverter":"I14","avg":0.8518},{"date":"2026-03-11","inverter":"I15","avg":0.8629},{"date":"2026-03-11","inverter":"I16","avg":0.8356},{"date":"2026-03-11","inverter":"I17","avg":0.8422},{"date":"2026-03-11","inverter":"I18","avg":0.8163},{"date":"2026-03-11","inverter":"I19","avg":0.8011},{"date":"2026-03-11","inverter":"I20","avg":0.9200},{"date":"2026-03-11","inverter":"I21","avg":0.8727},{"date":"2026-03-11","inverter":"I22","avg":0.8680},{"date":"2026-03-11","inverter":"I23","avg":0.8653},{"date":"2026-03-11","inverter":"I24","avg":0.8640},{"date":"2026-03-11","inverter":"I25","avg":0.8675},{"date":"2026-03-11","inverter":"I26","avg":0.8681},{"date":"2026-03-11","inverter":"I27","avg":0.8688},{"date":"2026-03-11","inverter":"I28","avg":0.8533},{"date":"2026-03-11","inverter":"I29","avg":0.8669},{"date":"2026-03-11","inverter":"I30","avg":0.8725},{"date":"2026-03-11","inverter":"I31","avg":0.8820},{"date":"2026-03-11","inverter":"I32","avg":0.8825},{"date":"2026-03-11","inverter":"I33","avg":0.8688},{"date":"2026-03-11","inverter":"I34","avg":0.8775},
    {"date":"2026-03-12","inverter":"I01","avg":0.8914},{"date":"2026-03-12","inverter":"I02","avg":0.8545},{"date":"2026-03-12","inverter":"I03","avg":0.8459},{"date":"2026-03-12","inverter":"I04","avg":0.8375},{"date":"2026-03-12","inverter":"I05","avg":0.8538},{"date":"2026-03-12","inverter":"I06","avg":0.8676},{"date":"2026-03-12","inverter":"I07","avg":0.8524},{"date":"2026-03-12","inverter":"I08","avg":0.7966},{"date":"2026-03-12","inverter":"I09","avg":0.8836},{"date":"2026-03-12","inverter":"I10","avg":0.8660},{"date":"2026-03-12","inverter":"I11","avg":0.8702},{"date":"2026-03-12","inverter":"I12","avg":0.8483},{"date":"2026-03-12","inverter":"I13","avg":0.8566},{"date":"2026-03-12","inverter":"I14","avg":0.8571},{"date":"2026-03-12","inverter":"I15","avg":0.8769},{"date":"2026-03-12","inverter":"I16","avg":0.8478},{"date":"2026-03-12","inverter":"I17","avg":0.8550},{"date":"2026-03-12","inverter":"I18","avg":0.8340},{"date":"2026-03-12","inverter":"I19","avg":0.8337},{"date":"2026-03-12","inverter":"I20","avg":0.9060},{"date":"2026-03-12","inverter":"I21","avg":0.8813},{"date":"2026-03-12","inverter":"I22","avg":0.8673},{"date":"2026-03-12","inverter":"I23","avg":0.8647},{"date":"2026-03-12","inverter":"I24","avg":0.8593},{"date":"2026-03-12","inverter":"I25","avg":0.8625},{"date":"2026-03-12","inverter":"I26","avg":0.8631},{"date":"2026-03-12","inverter":"I27","avg":0.8669},{"date":"2026-03-12","inverter":"I28","avg":0.8527},{"date":"2026-03-12","inverter":"I29","avg":0.8619},{"date":"2026-03-12","inverter":"I30","avg":0.8738},{"date":"2026-03-12","inverter":"I31","avg":0.8820},{"date":"2026-03-12","inverter":"I32","avg":0.8856},{"date":"2026-03-12","inverter":"I33","avg":0.8656},{"date":"2026-03-12","inverter":"I34","avg":0.8738},
    {"date":"2026-03-13","inverter":"I01","avg":0.8570},{"date":"2026-03-13","inverter":"I02","avg":0.8189},{"date":"2026-03-13","inverter":"I03","avg":0.8178},{"date":"2026-03-13","inverter":"I04","avg":0.8001},{"date":"2026-03-13","inverter":"I05","avg":0.8238},{"date":"2026-03-13","inverter":"I06","avg":0.8458},{"date":"2026-03-13","inverter":"I07","avg":0.8202},{"date":"2026-03-13","inverter":"I08","avg":0.7710},{"date":"2026-03-13","inverter":"I09","avg":0.8494},{"date":"2026-03-13","inverter":"I10","avg":0.8255},{"date":"2026-03-13","inverter":"I11","avg":0.8298},{"date":"2026-03-13","inverter":"I12","avg":0.8109},{"date":"2026-03-13","inverter":"I13","avg":0.8240},{"date":"2026-03-13","inverter":"I14","avg":0.8237},{"date":"2026-03-13","inverter":"I15","avg":0.8792},{"date":"2026-03-13","inverter":"I16","avg":0.8412},{"date":"2026-03-13","inverter":"I17","avg":0.8487},{"date":"2026-03-13","inverter":"I18","avg":0.8377},{"date":"2026-03-13","inverter":"I19","avg":0.8269},{"date":"2026-03-13","inverter":"I20","avg":0.9060},{"date":"2026-03-13","inverter":"I21","avg":0.8593},{"date":"2026-03-13","inverter":"I22","avg":0.8633},{"date":"2026-03-13","inverter":"I23","avg":0.8267},{"date":"2026-03-13","inverter":"I24","avg":0.8347},{"date":"2026-03-13","inverter":"I25","avg":0.8488},{"date":"2026-03-13","inverter":"I26","avg":0.8456},{"date":"2026-03-13","inverter":"I27","avg":0.8569},{"date":"2026-03-13","inverter":"I28","avg":0.8513},{"date":"2026-03-13","inverter":"I29","avg":0.8394},{"date":"2026-03-13","inverter":"I30","avg":0.8444},{"date":"2026-03-13","inverter":"I31","avg":0.8513},{"date":"2026-03-13","inverter":"I32","avg":0.8481},{"date":"2026-03-13","inverter":"I33","avg":0.8275},{"date":"2026-03-13","inverter":"I34","avg":0.8381},
    {"date":"2026-03-14","inverter":"I01","avg":0.8618},{"date":"2026-03-14","inverter":"I02","avg":0.8345},{"date":"2026-03-14","inverter":"I03","avg":0.8334},{"date":"2026-03-14","inverter":"I04","avg":0.8269},{"date":"2026-03-14","inverter":"I05","avg":0.8125},{"date":"2026-03-14","inverter":"I06","avg":0.8244},{"date":"2026-03-14","inverter":"I07","avg":0.7441},{"date":"2026-03-14","inverter":"I08","avg":0.7479},{"date":"2026-03-14","inverter":"I09","avg":0.8474},{"date":"2026-03-14","inverter":"I10","avg":0.8269},{"date":"2026-03-14","inverter":"I11","avg":0.8108},{"date":"2026-03-14","inverter":"I12","avg":0.7578},{"date":"2026-03-14","inverter":"I13","avg":0.7830},{"date":"2026-03-14","inverter":"I14","avg":0.7728},{"date":"2026-03-14","inverter":"I15","avg":0.7041},{"date":"2026-03-14","inverter":"I16","avg":0.7568},{"date":"2026-03-14","inverter":"I17","avg":0.7496},{"date":"2026-03-14","inverter":"I18","avg":0.6826},{"date":"2026-03-14","inverter":"I19","avg":0.6657},{"date":"2026-03-14","inverter":"I20","avg":0.9000},{"date":"2026-03-14","inverter":"I21","avg":0.8813},{"date":"2026-03-14","inverter":"I22","avg":0.8813},{"date":"2026-03-14","inverter":"I23","avg":0.8593},{"date":"2026-03-14","inverter":"I24","avg":0.8580},{"date":"2026-03-14","inverter":"I25","avg":0.8438},{"date":"2026-03-14","inverter":"I26","avg":0.8519},{"date":"2026-03-14","inverter":"I27","avg":0.8706},{"date":"2026-03-14","inverter":"I28","avg":0.8633},{"date":"2026-03-14","inverter":"I29","avg":0.8288},{"date":"2026-03-14","inverter":"I30","avg":0.8356},{"date":"2026-03-14","inverter":"I31","avg":0.8580},{"date":"2026-03-14","inverter":"I32","avg":0.8500},{"date":"2026-03-14","inverter":"I33","avg":0.8194},{"date":"2026-03-14","inverter":"I34","avg":0.8162},
    {"date":"2026-03-15","inverter":"I01","avg":0.5864},{"date":"2026-03-15","inverter":"I02","avg":0.5386},{"date":"2026-03-15","inverter":"I03","avg":0.5368},{"date":"2026-03-15","inverter":"I04","avg":0.5613},{"date":"2026-03-15","inverter":"I05","avg":0.5588},{"date":"2026-03-15","inverter":"I06","avg":0.5825},{"date":"2026-03-15","inverter":"I07","avg":0.5899},{"date":"2026-03-15","inverter":"I08","avg":0.5486},{"date":"2026-03-15","inverter":"I09","avg":0.6665},{"date":"2026-03-15","inverter":"I10","avg":0.7107},{"date":"2026-03-15","inverter":"I11","avg":0.6750},{"date":"2026-03-15","inverter":"I12","avg":0.6035},{"date":"2026-03-15","inverter":"I13","avg":0.6177},{"date":"2026-03-15","inverter":"I14","avg":0.6087},{"date":"2026-03-15","inverter":"I15","avg":0.6602},{"date":"2026-03-15","inverter":"I16","avg":0.6258},{"date":"2026-03-15","inverter":"I17","avg":0.6137},{"date":"2026-03-15","inverter":"I18","avg":0.5143},{"date":"2026-03-15","inverter":"I19","avg":0.5040},{"date":"2026-03-15","inverter":"I20","avg":0.9120},{"date":"2026-03-15","inverter":"I21","avg":0.8553},{"date":"2026-03-15","inverter":"I22","avg":0.8440},{"date":"2026-03-15","inverter":"I23","avg":0.9353},{"date":"2026-03-15","inverter":"I24","avg":0.9213},{"date":"2026-03-15","inverter":"I25","avg":0.8906},{"date":"2026-03-15","inverter":"I26","avg":0.8862},{"date":"2026-03-15","inverter":"I27","avg":0.8881},{"date":"2026-03-15","inverter":"I28","avg":0.8820},{"date":"2026-03-15","inverter":"I29","avg":0.8950},{"date":"2026-03-15","inverter":"I30","avg":0.8981},{"date":"2026-03-15","inverter":"I31","avg":0.9267},{"date":"2026-03-15","inverter":"I32","avg":0.9225},{"date":"2026-03-15","inverter":"I33","avg":0.9056},{"date":"2026-03-15","inverter":"I34","avg":0.9025}
  ]
};

// ============================================================
// KPI CALCULATIONS
// ============================================================
const KPI = {
  weeklyAvgPerformance: () => {
    const avg = PLANT_DATA.daily.reduce((s, d) => s + d.avg, 0) / PLANT_DATA.daily.length;
    return (avg * 100).toFixed(2);
  },
  totalLowPerformers: () => PLANT_DATA.lowPerformance.reduce((s, d) => s + d.low_count, 0),
  anomalyRate: () => {
    const total = PLANT_DATA.daily.reduce((s, d) => s + d.count, 0);
    const low = PLANT_DATA.lowPerformance.reduce((s, d) => s + d.low_count, 0);
    return ((low / total) * 100).toFixed(1);
  },
  bestInverter: () => {
    const best = PLANT_DATA.inverters.reduce((a, b) => a.avg > b.avg ? a : b);
    return { inverter: best.inverter, avg: (best.avg * 100).toFixed(1) };
  },
  worstInverter: () => {
    const worst = PLANT_DATA.inverters.reduce((a, b) => a.avg < b.avg ? a : b);
    return { inverter: worst.inverter, avg: (worst.avg * 100).toFixed(1) };
  },
  trendSlope: () => {
    const avgs = PLANT_DATA.daily.map(d => d.avg);
    const n = avgs.length;
    const xs = avgs.map((_, i) => i);
    const xMean = xs.reduce((a, b) => a + b) / n;
    const yMean = avgs.reduce((a, b) => a + b) / n;
    const num = xs.reduce((s, x, i) => s + (x - xMean) * (avgs[i] - yMean), 0);
    const den = xs.reduce((s, x) => s + (x - xMean) ** 2, 0);
    return (num / den * 100).toFixed(3);
  }
};

// ============================================================
// MASTER DATASET (localStorage-backed)
// ============================================================
const MasterDataset = {
  KEY: 'solar_master_dataset',
  load() {
    try {
      const raw = localStorage.getItem(this.KEY);
      return raw ? JSON.parse(raw) : { months: {}, lastUpdated: null };
    } catch { return { months: {}, lastUpdated: null }; }
  },
  save(data) {
    localStorage.setItem(this.KEY, JSON.stringify(data));
  },
  upsert(monthKey, rows) {
    const dataset = this.load();
    const isUpdate = !!dataset.months[monthKey];
    dataset.months[monthKey] = { rows, uploadedAt: new Date().toISOString() };
    dataset.lastUpdated = new Date().toISOString();
    this.save(dataset);
    return isUpdate ? 'updated' : 'added';
  },
  getMonths() {
    return Object.keys(this.load().months).sort();
  }
};
